package com.rodric.ER_server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ErServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ErServerApplication.class, args);
	}

}
