"use client"

import { useState } from "react"
import { Navigation } from "@/components/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { ChevronDown, ChevronUp, HelpCircle, X } from "lucide-react"
import { cn } from "@/lib/utils"

// 실험체 목록 (전체)
const allCharacters = [
  { id: 1, name: "가넷", image: "/placeholder.svg?height=60&width=60" },
  { id: 2, name: "나딘", image: "/placeholder.svg?height=60&width=60" },
  { id: 3, name: "나타폰", image: "/placeholder.svg?height=60&width=60" },
  { id: 4, name: "니아", image: "/placeholder.svg?height=60&width=60" },
  { id: 5, name: "니키", image: "/placeholder.svg?height=60&width=60" },
  { id: 6, name: "다니엘", image: "/placeholder.svg?height=60&width=60" },
  { id: 7, name: "다르코", image: "/placeholder.svg?height=60&width=60" },
  { id: 8, name: "데비&마를렌", image: "/placeholder.svg?height=60&width=60" },
  { id: 9, name: "띠아", image: "/placeholder.svg?height=60&width=60" },
  { id: 10, name: "라우라", image: "/placeholder.svg?height=60&width=60" },
  { id: 11, name: "레녹스", image: "/placeholder.svg?height=60&width=60" },
  { id: 12, name: "레니", image: "/placeholder.svg?height=60&width=60" },
  { id: 13, name: "레온", image: "/placeholder.svg?height=60&width=60" },
  { id: 14, name: "로지", image: "/placeholder.svg?height=60&width=60" },
  { id: 15, name: "루크", image: "/placeholder.svg?height=60&width=60" },
  { id: 16, name: "르노어", image: "/placeholder.svg?height=60&width=60" },
  { id: 17, name: "리 다이린", image: "/placeholder.svg?height=60&width=60" },
  { id: 18, name: "리오", image: "/placeholder.svg?height=60&width=60" },
  { id: 19, name: "마르티나", image: "/placeholder.svg?height=60&width=60" },
  { id: 20, name: "마이", image: "/placeholder.svg?height=60&width=60" },
  { id: 21, name: "마커스", image: "/placeholder.svg?height=60&width=60" },
  { id: 22, name: "매그너스", image: "/placeholder.svg?height=60&width=60" },
  { id: 23, name: "미르카", image: "/placeholder.svg?height=60&width=60" },
  { id: 24, name: "바나", image: "/placeholder.svg?height=60&width=60" },
  { id: 25, name: "헤이즈", image: "/placeholder.svg?height=60&width=60" },
  { id: 26, name: "아야", image: "/placeholder.svg?height=60&width=60" },
  { id: 27, name: "클로에", image: "/placeholder.svg?height=60&width=60" },
  { id: 28, name: "츠바메", image: "/placeholder.svg?height=60&width=60" },
]

// 샘플 조합 결과 데이터
const sampleResults = [
  {
    id: 1,
    members: ["데비 마를렌", "헤이즈", "아야 - 돌격소총"],
    score: 8.0,
    grade: "A",
  },
  {
    id: 2,
    members: ["데비 마를렌", "헤이즈", "나딘 - 석궁"],
    score: 7.9,
    grade: "A",
  },
  {
    id: 3,
    members: ["데비 마를렌", "헤이즈", "클로에"],
    score: 7.8,
    grade: "A",
  },
  {
    id: 4,
    members: ["데비 마를렌", "헤이즈", "츠바메"],
    score: 7.6,
    grade: "A",
  },
]

interface TeamMember {
  id: number | null
  name: string
  image: string
}

export default function SimulatorPage() {
  const [showHelp, setShowHelp] = useState(true)
  const [tier, setTier] = useState("top4")
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>([
    { id: 1, name: "데비 ...", image: "/placeholder.svg?height=60&width=60" },
    { id: 2, name: "헤이즈", image: "/placeholder.svg?height=60&width=60" },
    { id: null, name: "", image: "" },
  ])
  const [searchInputs, setSearchInputs] = useState(["", "", ""])
  const [expandedResult, setExpandedResult] = useState<number | null>(null)
  const [characterSearch, setCharacterSearch] = useState("")
  const [selectedCharacters, setSelectedCharacters] = useState<number[]>([])

  const filteredCharacters = allCharacters.filter((char) => {
    if (!characterSearch) return true
    return char.name.toLowerCase().includes(characterSearch.toLowerCase())
  })

  const handleCharacterSelect = (charId: number) => {
    if (selectedCharacters.includes(charId)) {
      setSelectedCharacters(selectedCharacters.filter((id) => id !== charId))
    } else {
      setSelectedCharacters([...selectedCharacters, charId])
    }
  }

  const handleRemoveMember = (index: number) => {
    const newMembers = [...teamMembers]
    newMembers[index] = { id: null, name: "", image: "" }
    setTeamMembers(newMembers)
  }

  const handleSearchChange = (index: number, value: string) => {
    const newInputs = [...searchInputs]
    newInputs[index] = value
    setSearchInputs(newInputs)
  }

  const filledMemberCount = teamMembers.filter((m) => m.id !== null).length

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="mx-auto max-w-6xl px-4 py-8">
        <h1 className="text-2xl font-bold text-foreground">조합 시뮬레이터</h1>

        {/* 도움말 섹션 */}
        <div className="mt-6 rounded-lg border border-primary/50 bg-primary/5 p-4">
          <div className="flex items-start justify-between">
            <div className="space-y-1 text-sm text-muted-foreground">
              <p>각 팀원의 실험체풀로 만들 수 있는 모든 조합의 추천도를 확인할 수 있습니다.</p>
              <p>조합의 추천도는 개별 캐릭터 티어, 2인 조합 시너지, 실험체별 역할군 조합 시너지를 모두 고려하여 측정됩니다.</p>
              <p>세 팀원을 모두 입력 시, 가능한 모든 조합을 추천도 순으로 표시합니다. (속도 빠름)</p>
              <p>두 명만 입력 시, 둘의 실험체풀에서 가능한 3인 조합 중 상위 150개를 표시합니다. (10초 이상 소요)</p>
            </div>
            <button
              onClick={() => setShowHelp(!showHelp)}
              className="ml-4 flex shrink-0 items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
            >
              도움말 {showHelp ? "접기" : "펼치기"}
            </button>
          </div>
        </div>

        {/* 실험체 선택 그리드 */}
        <div className="mt-6 rounded-lg border border-border bg-card p-4">
          <h2 className="text-lg font-bold text-foreground">실험체 선택</h2>
          
          <div className="mt-4">
            <Input
              placeholder="실험체 검색 (예: 나딘, ㄴㄷ)"
              value={characterSearch}
              onChange={(e) => setCharacterSearch(e.target.value)}
              className="w-full"
            />
          </div>

          <div className="mt-4 max-h-80 overflow-y-auto">
            <div className="grid grid-cols-5 gap-3 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-10">
              {filteredCharacters.map((char) => {
                const isSelected = selectedCharacters.includes(char.id)
                return (
                  <button
                    key={char.id}
                    onClick={() => handleCharacterSelect(char.id)}
                    className={cn(
                      "flex flex-col items-center gap-1 rounded-lg p-2 transition-colors",
                      isSelected
                        ? "bg-primary/20 ring-2 ring-primary"
                        : "hover:bg-secondary"
                    )}
                  >
                    <div className="relative h-12 w-12 overflow-hidden rounded-full bg-secondary">
                      <img
                        src={char.image}
                        alt={char.name}
                        className="h-full w-full object-cover"
                      />
                    </div>
                    <span className="text-xs text-foreground text-center leading-tight">
                      {char.name}
                    </span>
                  </button>
                )
              })}
            </div>
          </div>

          {selectedCharacters.length > 0 && (
            <div className="mt-4 flex items-center gap-2 text-sm text-muted-foreground">
              <span>{selectedCharacters.length}개 선택됨</span>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setSelectedCharacters([])}
                className="h-6 text-xs"
              >
                선택 초기화
              </Button>
            </div>
          )}
        </div>

        {/* 티어 구간 선택 */}
        <div className="mt-6 flex items-center gap-3">
          <span className="text-sm text-muted-foreground">티어 구간:</span>
          <Select value={tier} onValueChange={setTier}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="top1">상위 1%</SelectItem>
              <SelectItem value="top4">상위 4%</SelectItem>
              <SelectItem value="top10">상위 10%</SelectItem>
              <SelectItem value="top25">상위 25%</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* 팀원 선택 카드 */}
        <div className="mt-6 grid gap-4 md:grid-cols-3">
          {[0, 1, 2].map((index) => {
            const member = teamMembers[index]
            const hasMember = member.id !== null

            return (
              <div
                key={index}
                className="rounded-lg border border-border bg-card p-4"
              >
                <div className="flex items-center justify-between">
                  <span className="font-medium text-foreground">
                    팀원 {index + 1}
                  </span>
                  {index === 0 && (
                    <Button
                      variant="outline"
                      size="sm"
                      className="h-7 border-primary/50 text-xs text-primary"
                    >
                      내 실험체폭 ON
                    </Button>
                  )}
                </div>

                <div className="mt-4 flex flex-col items-center">
                  {hasMember ? (
                    <>
                      <div className="relative h-16 w-16 overflow-hidden rounded-full bg-secondary">
                        <img
                          src={member.image}
                          alt={member.name}
                          className="h-full w-full object-cover"
                        />
                      </div>
                      <span className="mt-2 text-sm text-foreground">
                        {member.name}
                      </span>
                    </>
                  ) : (
                    <>
                      <div className="flex h-16 w-16 items-center justify-center rounded-full bg-secondary">
                        <HelpCircle className="h-8 w-8 text-muted-foreground" />
                      </div>
                      <span className="mt-2 text-sm text-muted-foreground">
                        실험체를 검색해 주세요. (최대 5개)
                      </span>
                    </>
                  )}
                </div>

                <div className="relative mt-4">
                  <Input
                    placeholder="실험체 검색 (클릭으로 제거)"
                    value={searchInputs[index]}
                    onChange={(e) => handleSearchChange(index, e.target.value)}
                    className="pr-8"
                  />
                  {hasMember && (
                    <button
                      onClick={() => handleRemoveMember(index)}
                      className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  )}
                </div>
              </div>
            )
          })}
        </div>

        {/* 조합 추천 결과 */}
        <div className="mt-10">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-foreground">조합 추천 결과</h2>
            <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
              {filledMemberCount}인 조합 계산
            </Button>
          </div>

          <div className="mt-4 space-y-2">
            {sampleResults.map((result) => (
              <div
                key={result.id}
                className="rounded-lg border border-border bg-card"
              >
                <div className="flex items-center justify-between p-4">
                  <div className="flex items-center gap-6">
                    {result.members.map((memberName, idx) => (
                      <div key={idx} className="flex items-center gap-2">
                        <div className="h-10 w-10 overflow-hidden rounded-full bg-secondary">
                          <img
                            src="/placeholder.svg?height=40&width=40"
                            alt={memberName}
                            className="h-full w-full object-cover"
                          />
                        </div>
                        <span className="text-sm text-foreground">
                          {memberName}
                        </span>
                      </div>
                    ))}
                  </div>

                  <div className="flex items-center gap-4">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() =>
                        setExpandedResult(
                          expandedResult === result.id ? null : result.id
                        )
                      }
                      className="gap-1"
                    >
                      상세보기
                      {expandedResult === result.id ? (
                        <ChevronUp className="h-4 w-4" />
                      ) : (
                        <ChevronDown className="h-4 w-4" />
                      )}
                    </Button>

                    <div className="flex flex-col items-end">
                      <span
                        className={cn(
                          "text-3xl font-bold",
                          result.grade === "A" && "text-primary",
                          result.grade === "B" && "text-green-500",
                          result.grade === "C" && "text-yellow-500"
                        )}
                      >
                        {result.grade}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        점수 {result.score.toFixed(1)}
                      </span>
                    </div>
                  </div>
                </div>

                {expandedResult === result.id && (
                  <div className="border-t border-border p-4">
                    <p className="text-sm text-muted-foreground">
                      상세 시너지 정보가 여기에 표시됩니다.
                    </p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </main>

      <footer className="border-t border-border py-8">
        <div className="mx-auto max-w-6xl px-4 text-center text-sm text-muted-foreground">
          <p>&copy; 2026 StatTracker. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}
